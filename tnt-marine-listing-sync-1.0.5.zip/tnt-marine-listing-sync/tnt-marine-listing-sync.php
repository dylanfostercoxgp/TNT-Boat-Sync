<?php
/**
 * Plugin Name:  TNT Marine Listing Sync
 * Plugin URI:   https://ideaboss.io
 * Description:  Syncs boat listings from Google Sheets (Active Listings + Sold tabs) to the marine_listing CPT. Configurable sync interval, dual-tab support, diagnostics, and full Settings page.
 * Version:      1.0.5
 * Author:       ideaBoss.io
 * Author URI:   https://ideaboss.io
 * License:      GPL-2.0+
 * Text Domain:  tnt-sync
 */

if ( ! defined( 'ABSPATH' ) ) exit;


// ============================================================
//  1.  CONSTANTS
// ============================================================

define( 'TNTS_VERSION',             '1.0.5' );
define( 'TNTS_CPT',                 'marine_listing' );
define( 'TNTS_STOCK_META',          '_tnt_stock_id' );
define( 'TNTS_CRON_HOOK',           'tnt_sync_cron_event' );
define( 'TNTS_DAILY_EMAIL_HOOK',    'tnt_daily_email_event' );
define( 'TNTS_SA_EMAIL',            'tnt-marine-sync@tnt-marine-listings.iam.gserviceaccount.com' );

// Defaults — overridable via Settings page
define( 'TNTS_DEFAULT_SHEET_ID',    '1LIp4LtlxhuzdK5lrjHKKKlVIRiAzxDlHOex3xGgdekk' );
define( 'TNTS_DEFAULT_ACTIVE_TAB',  'Active Listings' );
define( 'TNTS_DEFAULT_SOLD_TAB',    'Sold' );
define( 'TNTS_DEFAULT_INTERVAL',    3600 ); // 1 hour


// ============================================================
//  2.  OPTIONS HELPERS
// ============================================================

function tnts_opt( $key, $default = '' ) {
    return get_option( 'tnts_' . $key, $default );
}

// Always trim tab names to prevent invisible whitespace mismatches.
function tnts_sheet_id()          { return trim( tnts_opt( 'sheet_id',          TNTS_DEFAULT_SHEET_ID ) );   }
function tnts_active_tab()        { return trim( tnts_opt( 'active_tab',         TNTS_DEFAULT_ACTIVE_TAB ) ); }
function tnts_sold_tab()          { return trim( tnts_opt( 'sold_tab',           TNTS_DEFAULT_SOLD_TAB ) );   }
function tnts_interval()          { return (int) tnts_opt( 'interval',           TNTS_DEFAULT_INTERVAL );     }
function tnts_sync_enabled()      { return tnts_opt( 'sync_enabled',      '1' ) === '1';                     }
function tnts_sync_images()       { return tnts_opt( 'sync_images',       '1' ) === '1';                     }
function tnts_max_images()        { return max( 1, (int) tnts_opt( 'max_images', 20 ) );                     }
function tnts_sold_force_sold()   { return tnts_opt( 'sold_force_sold',   '1' ) === '1';                     }
function tnts_default_status()    { return tnts_opt( 'default_status',    'publish' );                       }
function tnts_notify_email()      { return trim( tnts_opt( 'notify_email', '' ) );                           }
function tnts_log_verbosity()     { return tnts_opt( 'log_verbosity',     'normal' );                        }


// ============================================================
//  3.  SERVICE ACCOUNT PRIVATE KEY
// ============================================================

function tnts_sa_private_key() {
    return "-----BEGIN PRIVATE KEY-----\n"
        . "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCojKMhNvB99EAC\n"
        . "J2Zd9MG89ADETk6727cmg7ca0QXNiXWgOL38XOlC7gDMFkVZJxkh1yCYy10lzoY6\n"
        . "jKQnJ8R/hAyPwOZQj2ifLdZbLmqx8ruEKb2KgklcExc1JcwTyZH7/a8TZOUXidyR\n"
        . "QShiJBXBkY4UsBiv1XP30Yw2TnMzda1kFIoLWZYExKCyntIIXpoOt8P1T/l76biS\n"
        . "2dBdogO/UA2GmmGjX3GpPARebAbs4fOeDkYHb+k6Y/NFI6GSFImdvnwMB/FUE2hf\n"
        . "WqDh6ppWQqTROrSIG2tVODujHvKCKhEZ78TckDi9L98JP73eemDZETl93QTSXczy\n"
        . "TuXHThJpAgMBAAECggEADjmITvZPB6JEgKoIlqdgbmz9X5PoSyx44ZQ+MNIxNi6C\n"
        . "sdn4FsNUoGRrxs2eXq7RDS0VwC9xlg4+/9P8yp0tlUF0ufEivuvLfZulup5JPOlq\n"
        . "b/YB3B2wyUeHLuIYvhbF7klzrCRYvUrSRaQFH3tCJsr8/bv66WQPXHvf5HlseYwy\n"
        . "z8ayPRsI7Awy3/LjnkBtYaobi0sLBfli7MMD0KxvQJKXzmxxyQGW7ucBNZLac7Rt\n"
        . "EPztogYeag414K8Q9Ys0Awhtzb1taWHv7oW2B1GJ6rElAJKcJfMIBwI3BIP8MRcN\n"
        . "sLMm9zkho/6BuIb0Ok8SZZ9g30WupH/bfsP9PZhMcQKBgQDbW5BKhzWC+tZ/3RGv\n"
        . "WxETypW7Vija3i+29UrzKwFx32iPDgvF3FVfEl3MXrri5fO7QaGwMP41eRGFWSmu\n"
        . "ECrfMGBSnIoSz9Avz/kD6I+UN2uuPG4E873E3lr+byK2FLr3W45Otc4Smz222NDi\n"
        . "GBle+t/HayJwMh4YiKNlVKUTxQKBgQDEtFkEgzPbK2NqvmuBsVPWDndrSCgrY848\n"
        . "wqKCH8cg2Owmtu/jlx4SAtpTX1v51gNt2MqDpmmJKlASbAxjlJqts9a9oYO9hkhv\n"
        . "wZ3ZptmlyqUs1wEjoqjRRpQEAf9xd1PZX40H4lhlHr7XMIpovt3xZ59ZPAkJcJlP\n"
        . "2pT1+9KaVQKBgDk8Lu4DUYcXhBhgyliC3nXXijITTR2uk6ydXC0Or5XSwSlydMfv\n"
        . "sabY1/iXTxQdA/d8LIAYiHvTVysAFMwCE+2gZcGobq5x4tRW45aNe8kknMgdpGdO\n"
        . "YdmYWw3AWcJArngUP5FyBo78SqIG+JnFx/jsZK9X2OiFayzjmh66c0gxAoGAYoA1\n"
        . "O29AHnZhuGhWiYF1C/H+lvhxNRkrg32rxyGGo8o8pz5gbkWUR0yqa6mK81baLL2s\n"
        . "27QPkSJhKnh008DsnCM8W4Vv5Q5DY8M++mj1AHKzt/qKlX+0red7423krrskf+u7\n"
        . "QcF0pl55DmU+SimaFnLfdt37YIDEJRq+EVfjJGkCgYEAiNhs17VycJf85ki0Jqxj\n"
        . "z/LNKqneJhrrwZkCVKrMA1HXnKQdiabVu1eR0jNM3n1Sr4S/ReF0/Tnr9bhogpyq\n"
        . "nm5V7Q/ferSwkFTfTX1QPJDG1vEaL7bbJ22oBz2QhJjCx49pd27eDzSJjxNWlCpp\n"
        . "SB+UkmTR4DeWhtbVMQBnnok=\n"
        . "-----END PRIVATE KEY-----\n";
}


// ============================================================
//  4.  FIELD MAP  (Sheet column header => _tnt_* meta key)
// ============================================================

function tnts_field_map() {
    return [
        // Overview
        'Year *'                => '_tnt_year',
        'Model *'               => '_tnt_model',
        'Price *'               => '_tnt_price',
        'Length'                => '_tnt_length',
        'Location'              => '_tnt_location',
        'Class'                 => '_tnt_class',
        'Capacity'              => '_tnt_capacity',
        'Hours'                 => '_tnt_hours',
        // Specifications
        'Length Overall'        => '_tnt_length_overall',
        'Beam'                  => '_tnt_beam',
        'Dry Weight'            => '_tnt_dry_weight',
        'Fuel Tanks'            => '_tnt_fuel_tanks',
        // Propulsion
        'Engine Count'          => '_tnt_engine_count',
        'Engine 1 Make'         => '_tnt_engine_make_1',
        'Engine 1 Model'        => '_tnt_engine_model_1',
        'Engine 1 Power'        => '_tnt_engine_power_1',
        'Engine 1 Hours'        => '_tnt_engine_hours_1',
        'Engine 1 Fuel'         => '_tnt_engine_fuel_1',
        'Engine 2 Make'         => '_tnt_engine_make_2',
        'Engine 2 Model'        => '_tnt_engine_model_2',
        'Engine 2 Power'        => '_tnt_engine_power_2',
        'Engine 2 Hours'        => '_tnt_engine_hours_2',
        'Engine 2 Fuel'         => '_tnt_engine_fuel_2',
        'Engine 3 Make'         => '_tnt_engine_make_3',
        'Engine 3 Model'        => '_tnt_engine_model_3',
        'Engine 3 Power'        => '_tnt_engine_power_3',
        'Engine 3 Hours'        => '_tnt_engine_hours_3',
        'Engine 3 Fuel'         => '_tnt_engine_fuel_3',
        'Engine 4 Make'         => '_tnt_engine_make_4',
        'Engine 4 Model'        => '_tnt_engine_model_4',
        'Engine 4 Power'        => '_tnt_engine_power_4',
        'Engine 4 Hours'        => '_tnt_engine_hours_4',
        'Engine 4 Fuel'         => '_tnt_engine_fuel_4',
        'Engine 5 Make'         => '_tnt_engine_make_5',
        'Engine 5 Model'        => '_tnt_engine_model_5', // corrected via header parser
        'Engine 5 Power'        => '_tnt_engine_power_5',
        'Engine 5 Hours'        => '_tnt_engine_hours_5',
        'Engine 5 Fuel'         => '_tnt_engine_fuel_5',
        // Content
        'Description *'         => '_tnt_description',
        'Key Features'          => '_tnt_power_features',
        'Notes/Disclaimers'     => '_tnt_bonus',
        // Added in v1.0.1 — stored as raw text, no files downloaded
        'Videos Link(s)'        => '_tnt_videos',
        'Hi Res Photos Link(s)' => '_tnt_hi_res_photos',
        'Keywords'              => '_tnt_keywords',
    ];
}


// ============================================================
//  5.  GOOGLE AUTH — Service Account JWT → Access Token
// ============================================================

function tnts_b64url( $data ) {
    return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
}

/**
 * Returns a valid Google OAuth 2.0 access token, cached for ~58 min.
 * Pass $force = true to bypass the cache (used by the Clear Token button).
 *
 * @return string|WP_Error
 */
function tnts_get_access_token( $force = false ) {
    if ( ! $force ) {
        $cached = get_transient( 'tnts_google_token' );
        if ( $cached ) return $cached;
    }

    if ( ! function_exists( 'openssl_sign' ) ) {
        return new WP_Error( 'tnts_openssl', 'PHP OpenSSL extension is required but not available on this server.' );
    }

    $pkey = openssl_pkey_get_private( tnts_sa_private_key() );
    if ( ! $pkey ) {
        return new WP_Error( 'tnts_key', 'Could not parse service account private key.' );
    }

    $now    = time();
    $header = tnts_b64url( json_encode( [ 'alg' => 'RS256', 'typ' => 'JWT' ] ) );
    $claims = tnts_b64url( json_encode( [
        'iss'   => TNTS_SA_EMAIL,
        'scope' => 'https://www.googleapis.com/auth/spreadsheets.readonly https://www.googleapis.com/auth/drive.readonly',
        'aud'   => 'https://oauth2.googleapis.com/token',
        'iat'   => $now,
        'exp'   => $now + 3600,
    ] ) );

    $signing_input = $header . '.' . $claims;
    openssl_sign( $signing_input, $signature, $pkey, OPENSSL_ALGO_SHA256 );
    $jwt = $signing_input . '.' . tnts_b64url( $signature );

    $resp = wp_remote_post( 'https://oauth2.googleapis.com/token', [
        'timeout' => 20,
        'body'    => [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion'  => $jwt,
        ],
    ] );

    if ( is_wp_error( $resp ) ) return $resp;

    $body  = json_decode( wp_remote_retrieve_body( $resp ), true );
    $token = $body['access_token'] ?? null;

    if ( ! $token ) {
        $detail = $body['error_description'] ?? $body['error'] ?? wp_remote_retrieve_body( $resp );
        return new WP_Error( 'tnts_auth', 'Google token exchange failed: ' . $detail );
    }

    set_transient( 'tnts_google_token', $token, 3500 );
    return $token;
}


// ============================================================
//  6.  GOOGLE SHEETS — Fetch rows from a named tab
// ============================================================

/**
 * Fetches all rows starting at row 2 (row 1 = group labels, row 2 = headers, row 3+ = data).
 * Returns [ rows_array, diagnostic_string ] tuple.
 *
 * @param  string $token  OAuth access token.
 * @param  string $tab    Exact tab name as it appears in the Sheet.
 * @return array|WP_Error 2-D array of rows, first row being the header row.
 */
function tnts_fetch_sheet_rows( $token, $tab ) {
    // Single-quote wrap required for tab names with spaces; rawurlencode for path safety.
    $range = rawurlencode( "'{$tab}'!A2:AZ" );
    $url   = 'https://sheets.googleapis.com/v4/spreadsheets/' . tnts_sheet_id() . '/values/' . $range;

    $resp = wp_remote_get( $url, [
        'headers' => [ 'Authorization' => 'Bearer ' . $token ],
        'timeout' => 30,
    ] );

    if ( is_wp_error( $resp ) ) return $resp;

    $code = wp_remote_retrieve_response_code( $resp );
    if ( $code !== 200 ) {
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $msg  = $body['error']['message'] ?? wp_remote_retrieve_body( $resp );
        return new WP_Error( 'tnts_sheets', "HTTP {$code}: {$msg}" );
    }

    $body = json_decode( wp_remote_retrieve_body( $resp ), true );
    return $body['values'] ?? [];
}


// ============================================================
//  7.  GOOGLE DRIVE — Sideload one image into WP Media Library
// ============================================================

/**
 * Downloads a Drive file by ID and imports it into the WP media library.
 * Uses _tnt_drive_file_id meta to prevent re-downloading on subsequent syncs.
 *
 * @param  string $file_id Drive file ID.
 * @param  string $token   OAuth access token.
 * @param  int    $post_id Parent post to attach media to.
 * @return int|WP_Error    Attachment post ID or error.
 */
function tnts_sideload_drive_image( $file_id, $token, $post_id ) {

    // Deduplication check
    $existing = get_posts( [
        'post_type'      => 'attachment',
        'meta_key'       => '_tnt_drive_file_id',
        'meta_value'     => $file_id,
        'posts_per_page' => 1,
        'post_status'    => 'any',
        'fields'         => 'ids',
    ] );
    if ( ! empty( $existing ) ) return $existing[0];

    // Fetch file name + MIME type
    $meta_resp = wp_remote_get(
        "https://www.googleapis.com/drive/v3/files/{$file_id}?fields=name,mimeType",
        [ 'headers' => [ 'Authorization' => 'Bearer ' . $token ], 'timeout' => 15 ]
    );
    if ( is_wp_error( $meta_resp ) || wp_remote_retrieve_response_code( $meta_resp ) !== 200 ) {
        return new WP_Error( 'tnts_drive_meta', "Could not fetch Drive metadata for ID: {$file_id}" );
    }
    $meta     = json_decode( wp_remote_retrieve_body( $meta_resp ), true );
    $filename = sanitize_file_name( $meta['name'] ?? ( $file_id . '.jpg' ) );

    // Stream download to temp file
    $tmpfile = wp_tempnam( $filename );
    $dl_resp = wp_remote_get(
        "https://www.googleapis.com/drive/v3/files/{$file_id}?alt=media",
        [
            'headers'  => [ 'Authorization' => 'Bearer ' . $token ],
            'timeout'  => 120,
            'stream'   => true,
            'filename' => $tmpfile,
        ]
    );
    if ( is_wp_error( $dl_resp ) || wp_remote_retrieve_response_code( $dl_resp ) !== 200 ) {
        @unlink( $tmpfile );
        return new WP_Error( 'tnts_drive_dl', "Could not download Drive file ID: {$file_id}" );
    }

    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    $attach_id = media_handle_sideload(
        [ 'name' => $filename, 'tmp_name' => $tmpfile ],
        $post_id,
        $filename
    );
    if ( is_wp_error( $attach_id ) ) {
        @unlink( $tmpfile );
        return $attach_id;
    }

    update_post_meta( $attach_id, '_tnt_drive_file_id', $file_id );
    return $attach_id;
}


// ============================================================
//  8.  HEADER PARSER — builds column-index lookup, fixes sheet typo
// ============================================================

/**
 * Converts a raw header row into a [ 'Column Name' => column_index ] map.
 * Corrects the sheet typo where "Engine 4 Model" appears twice —
 * the second occurrence is mapped as "Engine 5 Model".
 *
 * @param  array $raw_headers First row returned from the Sheets API.
 * @return array
 */
function tnts_build_col_index( array $raw_headers ) {
    $col_index     = [];
    $header_counts = [];

    foreach ( $raw_headers as $i => $h ) {
        $h = trim( $h );
        $header_counts[ $h ] = ( $header_counts[ $h ] ?? 0 ) + 1;

        if ( $h === 'Engine 4 Model' && $header_counts[ $h ] === 2 ) {
            $col_index['Engine 5 Model'] = $i;
        } else {
            $col_index[ $h ] = $i;
        }
    }

    return $col_index;
}


// ============================================================
//  9.  ROW PROCESSOR — shared logic for Active Listings + Sold tabs
// ============================================================

/**
 * Upserts all data rows from one Sheet tab into the marine_listing CPT.
 * Uses MD5 hash of the row + tab label to skip rows that have not changed since the last sync.
 *
 * @param  array  $rows        All rows from the tab, including header row as first element.
 * @param  string $token       OAuth access token.
 * @param  bool   $force_sold  If true, mark every row as sold regardless of Status column.
 * @param  string $tab_label   Tab name included in the hash so moving a boat between tabs forces a re-process.
 * @return array               [ added, updated, img_proc, errors, skipped, log ]
 */
function tnts_process_rows( array $rows, $token, $force_sold = false, $tab_label = '' ) {
    if ( empty( $rows ) ) return [ 0, 0, 0, 0, 0, [] ];

    $raw_headers    = array_shift( $rows );
    $col_index      = tnts_build_col_index( $raw_headers );
    $field_map      = tnts_field_map();
    $total_cols     = count( $raw_headers );
    $do_images      = tnts_sync_images();
    $max_imgs       = tnts_max_images();
    $default_status = tnts_default_status();
    $verbose        = ( tnts_log_verbosity() === 'verbose' );

    $added    = 0;
    $updated  = 0;
    $img_proc = 0;
    $errors   = 0;
    $skipped  = 0;
    $log      = [];

    if ( $verbose ) {
        $detected = implode( ', ', array_keys( $col_index ) );
        $log[] = "  [DEBUG] Columns detected (" . count( $col_index ) . "): {$detected}";
    }

    foreach ( $rows as $row_num => $row ) {

        // Ensure all columns exist even if Google omits trailing empty cells
        $row = array_pad( $row, $total_cols, '' );

        $stock_id = trim( $row[ $col_index['ID']      ?? 0 ] ?? '' );
        $title    = trim( $row[ $col_index['Title *'] ?? 1 ] ?? '' );
        $status   = strtolower( trim( $row[ $col_index['Status'] ?? 2 ] ?? '' ) );
        $photos   = isset( $col_index['Photos'] ) ? trim( $row[ $col_index['Photos'] ] ?? '' ) : '';

        if ( $stock_id === '' ) continue;

        // ── Hash-based change detection ──────────────────────────────────────────
        // Hash includes the tab label so moving a boat between tabs always triggers
        // a re-process even if the row data itself is identical.
        $row_hash = md5( $tab_label . implode( '|', $row ) );

        $existing_pre = get_posts( [
            'post_type'      => TNTS_CPT,
            'meta_key'       => TNTS_STOCK_META,
            'meta_value'     => $stock_id,
            'posts_per_page' => 1,
            'post_status'    => 'any',
            'fields'         => 'ids',
        ] );

        if ( ! empty( $existing_pre ) ) {
            $stored_hash = get_post_meta( $existing_pre[0], '_tnt_row_hash', true );
            if ( $stored_hash === $row_hash ) {
                // Nothing changed — skip this row entirely, no log entry.
                $skipped++;
                continue;
            }
        }
        // ─────────────────────────────────────────────────────────────────────────

        // Resolve WordPress post status and sold flag
        if ( $force_sold ) {
            $post_status = 'publish';
            $sold_flag   = '1';
        } else {
            switch ( $status ) {
                case 'sold':
                    $post_status = 'publish';
                    $sold_flag   = '1';
                    break;
                case 'draft':
                    $post_status = 'draft';
                    $sold_flag   = '';
                    break;
                default: // 'publish' or empty — use the configured default
                    $post_status = $default_status;
                    $sold_flag   = '';
            }
        }

        // Upsert: reuse the lookup already performed for hash detection above.
        $existing = $existing_pre;

        $post_data = [
            'post_type'    => TNTS_CPT,
            'post_title'   => $title ?: "Listing #{$stock_id}",
            'post_status'  => $post_status,
            'post_content' => '',
        ];

        if ( ! empty( $existing ) ) {
            $post_data['ID'] = $existing[0];
            $post_id         = wp_update_post( $post_data, true );
            $action          = 'Updated';
            $updated++;
        } else {
            $post_id = wp_insert_post( $post_data, true );
            $action  = 'Added';
            $added++;
        }

        if ( is_wp_error( $post_id ) ) {
            $log[] = "  [ERROR] Stock ID {$stock_id}: " . $post_id->get_error_message();
            $errors++;
            continue;
        }

        // Core identifiers + row hash (stored so unchanged rows are skipped next run)
        update_post_meta( $post_id, TNTS_STOCK_META,   $stock_id );
        update_post_meta( $post_id, '_tnt_sold',        $sold_flag );
        update_post_meta( $post_id, '_tnt_row_hash',    $row_hash );

        // All mapped meta fields
        foreach ( $field_map as $col_name => $meta_key ) {
            if ( ! isset( $col_index[ $col_name ] ) ) continue;
            $val = trim( $row[ $col_index[ $col_name ] ] ?? '' );
            if ( $meta_key === '_tnt_description' ) {
                update_post_meta( $post_id, $meta_key, wp_kses_post( $val ) );
            } else {
                update_post_meta( $post_id, $meta_key, sanitize_textarea_field( $val ) );
            }
        }

        // ── Photos: Drive images — downloaded, sideloaded, and always kept in sync.
        //    When image sync is ON:
        //      • New URLs  → downloaded and added to the media library.
        //      • Existing  → deduplication prevents re-download.
        //      • Removed   → gallery / featured image cleared to match the sheet.
        //    When image sync is OFF, the gallery is left untouched.
        $row_img_count = 0;
        if ( $do_images ) {
            $attach_ids = [];
            $img_cap    = 0;

            if ( ! empty( $photos ) ) {
                $urls = array_filter( array_map( 'trim', explode( ',', $photos ) ) );

                foreach ( $urls as $url ) {
                    if ( $img_cap >= $max_imgs ) {
                        $log[] = "    [IMG] Max images ({$max_imgs}) reached for ID {$stock_id} — remaining skipped.";
                        break;
                    }

                    // Supports both /d/FILE_ID/ and ?id=FILE_ID URL formats
                    if (   preg_match( '#/d/([a-zA-Z0-9_-]+)#', $url, $m )
                        || preg_match( '#[?&]id=([a-zA-Z0-9_-]+)#', $url, $m ) ) {

                        $fid       = $m[1];
                        $attach_id = tnts_sideload_drive_image( $fid, $token, $post_id );

                        if ( is_wp_error( $attach_id ) ) {
                            $log[] = "    [IMG WARN] Drive ID {$fid}: " . $attach_id->get_error_message();
                        } elseif ( $attach_id ) {
                            $attach_ids[]  = $attach_id;
                            $row_img_count++;
                            $img_cap++;
                        }
                    }
                }
            }

            // Always write back — this is what removes photos when deleted from the sheet.
            if ( empty( $attach_ids ) ) {
                delete_post_thumbnail( $post_id );
                update_post_meta( $post_id, '_tnt_gallery_ids', '' );
                if ( ! empty( $photos ) ) {
                    $log[] = "    [IMG] No valid Drive URLs found — gallery cleared for ID {$stock_id}.";
                } elseif ( $verbose ) {
                    $log[] = "    [IMG] Photos column empty — gallery cleared for ID {$stock_id}.";
                }
            } else {
                set_post_thumbnail( $post_id, $attach_ids[0] );
                update_post_meta( $post_id, '_tnt_gallery_ids', implode( ',', $attach_ids ) );
                $img_proc += $row_img_count;
            }
        } elseif ( $verbose && ! empty( $photos ) ) {
            $log[] = "    [IMG SKIP] Image sync is disabled — photos not updated for ID {$stock_id}.";
        }

        $status_label = $post_status . ( $sold_flag ? '/sold' : '' );
        $log[] = sprintf(
            '[%s] ID %s — "%s"  (Post #%d | %s | %d img%s)',
            $action,
            $stock_id,
            $post_data['post_title'],
            $post_id,
            $status_label,
            $row_img_count,
            $row_img_count === 1 ? '' : 's'
        );
    }

    return [ $added, $updated, $img_proc, $errors, $skipped, $log ];
}


// ============================================================
// 10.  MAIN SYNC RUNNER — processes both Sheet tabs
// ============================================================

function tnts_run_sync() {

    $token = tnts_get_access_token();
    if ( is_wp_error( $token ) ) {
        return [ 'error' => $token->get_error_message(), 'log' => [] ];
    }

    $log      = [];
    $added    = 0;
    $updated  = 0;
    $img_proc = 0;
    $errors   = 0;
    $skipped  = 0;

    // ── Active Listings tab
    $active_tab  = tnts_active_tab();
    $log[]       = "Fetching tab: \"{$active_tab}\" (length: " . strlen( $active_tab ) . " chars)...";
    $active_rows = tnts_fetch_sheet_rows( $token, $active_tab );

    if ( is_wp_error( $active_rows ) ) {
        $log[] = "[ERROR] Active Listings tab \"{$active_tab}\": " . $active_rows->get_error_message();
        $log[] = "[TIP] Go to Boat Sync → Settings and verify the Active Listings tab name matches your sheet exactly (case-sensitive, no extra spaces).";
        $errors++;
    } else {
        $data_row_count = max( 0, count( $active_rows ) - 1 );
        $log[] = "── Active Listings tab: {$data_row_count} data row(s) found";

        if ( $data_row_count === 0 ) {
            $log[] = "[WARN] 0 rows returned. Possible causes:";
            $log[] = "       1. Tab name mismatch — current setting: \"{$active_tab}\"";
            $log[] = "       2. Sheet has data but starts below row 3";
            $log[] = "       3. Service account lacks access to this sheet";
        } else {
            [ $a, $u, $i, $e, $sk, $tab_log ] = tnts_process_rows( $active_rows, $token, false, $active_tab );
            $added += $a;  $updated += $u;  $img_proc += $i;  $errors += $e;  $skipped += $sk;
            $log    = array_merge( $log, $tab_log );
        }
    }

    // ── Sold tab
    $sold_tab   = tnts_sold_tab();
    $force_sold = tnts_sold_force_sold();
    $log[]      = "Fetching tab: \"{$sold_tab}\" (length: " . strlen( $sold_tab ) . " chars)...";
    $sold_rows  = tnts_fetch_sheet_rows( $token, $sold_tab );

    if ( is_wp_error( $sold_rows ) ) {
        $log[] = "[ERROR] Sold tab \"{$sold_tab}\": " . $sold_rows->get_error_message();
        $log[] = "[TIP] Go to Boat Sync → Settings and verify the Sold tab name matches your sheet exactly.";
        $errors++;
    } else {
        $data_row_count = max( 0, count( $sold_rows ) - 1 );
        $log[] = "── Sold tab: {$data_row_count} data row(s) found" . ( $force_sold ? ' (Force Sold ON)' : '' );

        if ( $data_row_count === 0 ) {
            $log[] = "[WARN] 0 rows — tab may be empty or name mismatch. Current setting: \"{$sold_tab}\"";
        } else {
            [ $a, $u, $i, $e, $sk, $tab_log ] = tnts_process_rows( $sold_rows, $token, $force_sold, $sold_tab );
            $added += $a;  $updated += $u;  $img_proc += $i;  $errors += $e;  $skipped += $sk;
            $log    = array_merge( $log, $tab_log );
        }
    }

    // Summary line — prepended so it appears first in the log output
    array_unshift( $log, sprintf(
        'Sync complete at %s — %d added, %d updated, %d unchanged (skipped), %d images, %d error(s).',
        current_time( 'Y-m-d H:i:s' ),
        $added, $updated, $skipped, $img_proc, $errors
    ) );

    $log_text = implode( "\n", $log );
    update_option( 'tnts_last_sync', current_time( 'mysql' ) );
    update_option( 'tnts_last_log',  $log_text );

    // Accumulate stats into the rolling daily summary (sent at 10 am by separate cron).
    tnts_accumulate_daily_stats( $added, $updated, $skipped, $img_proc, $errors, $log );

    return compact( 'log', 'added', 'updated', 'skipped', 'img_proc', 'errors' );
}

// Mail filter callbacks
function tnts_mail_html_content_type() { return 'text/html'; }
function tnts_mail_from_address()      { return 'TNTSync@tntcustommarine.com'; }
function tnts_mail_from_name()         { return 'TNT Marine Sync'; }


// ============================================================
// 10b. DAILY STATS ACCUMULATOR
//      Each sync run appends its totals here.
//      Reset happens inside tnts_send_daily_summary() after the email is sent.
// ============================================================

/**
 * Merges this sync run's results into the rolling daily option.
 * Only changed items (added / updated) are stored in the activity list —
 * skipped rows are counted but never listed.
 */
function tnts_accumulate_daily_stats( $added, $updated, $skipped, $img_proc, $errors, array $log ) {
    $today   = current_time( 'Y-m-d' );
    $current = get_option( 'tnts_daily_stats', [] );

    // Reset if it's a new calendar day
    if ( ( $current['date'] ?? '' ) !== $today ) {
        $current = [
            'date'       => $today,
            'sync_count' => 0,
            'added'      => 0,
            'updated'    => 0,
            'skipped'    => 0,
            'img_proc'   => 0,
            'errors'     => 0,
            'activity'   => [], // Changed-listing lines only
            'error_lines'=> [],
        ];
    }

    $current['sync_count'] += 1;
    $current['added']      += $added;
    $current['updated']    += $updated;
    $current['skipped']    += $skipped;
    $current['img_proc']   += $img_proc;
    $current['errors']     += $errors;

    // Collect only lines that represent a real change or error
    foreach ( $log as $line ) {
        if ( preg_match( '/^\[(Added|Updated)\]/', $line ) ) {
            $current['activity'][]    = $line;
        } elseif ( strpos( $line, '[ERROR]' ) !== false ) {
            $current['error_lines'][] = $line;
        }
    }

    update_option( 'tnts_daily_stats', $current );
}


// ============================================================
// 10c. DAILY 10 AM EMAIL SENDER
// ============================================================

/**
 * Returns a UTC timestamp for the next 10:00 AM in the site's configured timezone.
 */
function tnts_next_10am_utc() {
    $tz_string = get_option( 'timezone_string' );
    if ( ! $tz_string ) {
        $offset    = (float) get_option( 'gmt_offset', 0 );
        $tz_string = timezone_name_from_abbr( '', (int) ( $offset * 3600 ), false ) ?: 'UTC';
    }
    try {
        $tz = new DateTimeZone( $tz_string );
    } catch ( Exception $e ) {
        $tz = new DateTimeZone( 'UTC' );
    }

    $now = new DateTime( 'now', $tz );
    $target = clone $now;
    $target->setTime( 10, 0, 0 );

    // If 10am has already passed today, schedule for tomorrow
    if ( $target <= $now ) {
        $target->modify( '+1 day' );
    }

    return $target->getTimestamp(); // UTC
}

/**
 * Fires once daily at 10 am. Sends the accumulated summary then resets the counter.
 */
function tnts_send_daily_summary() {
    $notify = tnts_notify_email();
    if ( ! $notify ) return;

    $stats  = get_option( 'tnts_daily_stats', [] );
    $today  = current_time( 'Y-m-d' );

    // Nothing accumulated yet today — still send a "all quiet" notice
    $added      = (int) ( $stats['added']      ?? 0 );
    $updated    = (int) ( $stats['updated']    ?? 0 );
    $skipped    = (int) ( $stats['skipped']    ?? 0 );
    $img_proc   = (int) ( $stats['img_proc']   ?? 0 );
    $errors     = (int) ( $stats['errors']     ?? 0 );
    $sync_count = (int) ( $stats['sync_count'] ?? 0 );
    $activity   = (array) ( $stats['activity']    ?? [] );
    $err_lines  = (array) ( $stats['error_lines'] ?? [] );

    $subject = $errors > 0
        ? sprintf( '[TNT Marine] ⚠ Daily Sync Report — %d error(s) · %s', $errors, current_time( 'M j, Y' ) )
        : sprintf( '[TNT Marine] ✓ Daily Sync Report — %s', current_time( 'M j, Y' ) );

    add_filter( 'wp_mail_content_type', 'tnts_mail_html_content_type' );
    add_filter( 'wp_mail_from',         'tnts_mail_from_address' );
    add_filter( 'wp_mail_from_name',    'tnts_mail_from_name' );

    wp_mail( $notify, $subject, tnts_build_daily_email( compact(
        'added', 'updated', 'skipped', 'img_proc', 'errors',
        'sync_count', 'activity', 'err_lines', 'today'
    ) ) );

    remove_filter( 'wp_mail_content_type', 'tnts_mail_html_content_type' );
    remove_filter( 'wp_mail_from',         'tnts_mail_from_address' );
    remove_filter( 'wp_mail_from_name',    'tnts_mail_from_name' );

    // Reset for the new day
    delete_option( 'tnts_daily_stats' );
}

add_action( TNTS_DAILY_EMAIL_HOOK, 'tnts_send_daily_summary' );


// ============================================================
// 10d. HTML EMAIL BUILDER — Daily Summary
// ============================================================

function tnts_build_daily_email( array $d ) {
    $added      = (int)   $d['added'];
    $updated    = (int)   $d['updated'];
    $skipped    = (int)   $d['skipped'];
    $img_proc   = (int)   $d['img_proc'];
    $errors     = (int)   $d['errors'];
    $sync_count = (int)   $d['sync_count'];
    $activity   = (array) $d['activity'];
    $err_lines  = (array) $d['err_lines'];
    $date_label = current_time( 'F j, Y' );

    $has_errors   = $errors > 0;
    $status_color = $has_errors ? '#D42B2B' : '#1a9e4f';
    $status_bg    = $has_errors ? '#fff0f0' : '#f0fff5';
    $status_label = $has_errors
        ? '⚠&nbsp; ' . $errors . ' error(s) detected today'
        : '✓&nbsp; All syncs completed successfully';

    // Activity rows HTML
    $activity_html = '';
    if ( ! empty( $activity ) ) {
        foreach ( $activity as $line ) {
            $is_added   = strpos( $line, '[Added]' )   !== false;
            $badge_bg   = $is_added ? '#e8f7ff' : '#f0fff4';
            $badge_color= $is_added ? '#0284c7' : '#15803d';
            $badge_text = $is_added ? 'New'     : 'Updated';
            // Strip the leading [Added] / [Updated] tag for clean display
            $clean = preg_replace( '/^\[(Added|Updated)\]\s*/', '', $line );
            $activity_html .= '
            <tr>
              <td style="padding:8px 0;border-bottom:1px solid #f5f5f5;font-size:13px;color:#333;vertical-align:middle;">
                <span style="display:inline-block;background:' . $badge_bg . ';color:' . $badge_color . ';font-size:10px;font-weight:700;letter-spacing:.8px;padding:2px 7px;border-radius:4px;text-transform:uppercase;margin-right:8px;vertical-align:middle;">'
                . $badge_text . '</span>'
                . esc_html( $clean ) . '
              </td>
            </tr>';
        }
    } else {
        $activity_html = '<tr><td style="padding:12px 0;font-size:13px;color:#999;font-style:italic;">No listing changes today — everything is up to date.</td></tr>';
    }

    // Error rows HTML
    $error_html = '';
    if ( ! empty( $err_lines ) ) {
        foreach ( $err_lines as $line ) {
            $error_html .= '<div style="color:#f92672;font-size:12px;line-height:1.7;font-family:\'Courier New\',monospace;">' . esc_html( $line ) . '</div>';
        }
    }

    ob_start();
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>TNT Marine — Daily Sync Report</title>
</head>
<body style="margin:0;padding:0;background:#f2f2f2;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f2f2f2;padding:32px 0;">
<tr><td align="center">
<table width="620" cellpadding="0" cellspacing="0" border="0" style="max-width:620px;width:100%;">

  <!-- HEADER -->
  <tr>
    <td style="background:#111111;border-radius:10px 10px 0 0;padding:36px 40px 24px;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td>
            <span style="font-size:28px;font-weight:900;letter-spacing:-0.5px;color:#fff;line-height:1;">
              <span style="color:#D42B2B;">TNT</span> MARINE
            </span>
            <div style="margin-top:5px;font-size:11px;letter-spacing:3px;text-transform:uppercase;color:#888;font-weight:500;">
              Daily Listing Sync Report
            </div>
          </td>
          <td align="right" valign="top">
            <div style="font-size:20px;font-weight:700;color:#fff;line-height:1;">
              <?php echo esc_html( current_time( 'M j' ) ); ?>
            </div>
            <div style="font-size:11px;color:#666;margin-top:3px;">
              <?php echo esc_html( current_time( 'Y' ) ); ?>
            </div>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- STATUS BANNER -->
  <tr>
    <td style="background:<?php echo $status_bg; ?>;border-left:4px solid <?php echo $status_color; ?>;padding:13px 40px;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td>
            <span style="font-size:14px;font-weight:700;color:<?php echo $status_color; ?>;">
              <?php echo $status_label; ?>
            </span>
          </td>
          <td align="right">
            <span style="font-size:12px;color:#888;">
              <?php echo $sync_count; ?> sync run<?php echo $sync_count !== 1 ? 's' : ''; ?> today
            </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- STAT CARDS -->
  <tr>
    <td style="background:#fff;padding:28px 40px 20px;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <?php
          $stats_row = [
              [ 'label' => 'New Listings',    'value' => $added,    'accent' => '#0ea5e9' ],
              [ 'label' => 'Updated',         'value' => $updated,  'accent' => '#22c55e' ],
              [ 'label' => 'Unchanged',       'value' => $skipped,  'accent' => '#94a3b8' ],
              [ 'label' => 'Images Synced',   'value' => $img_proc, 'accent' => '#f59e0b' ],
              [ 'label' => 'Errors',          'value' => $errors,   'accent' => $errors > 0 ? '#D42B2B' : '#94a3b8' ],
          ];
          foreach ( $stats_row as $s ) :
          ?>
          <td style="padding:0 4px 0 0;width:20%;">
            <div style="background:#f8fafc;border-top:3px solid <?php echo $s['accent']; ?>;border-radius:6px;padding:14px 10px;text-align:center;">
              <div style="font-size:24px;font-weight:900;color:#111;line-height:1;">
                <?php echo number_format( $s['value'] ); ?>
              </div>
              <div style="font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#94a3b8;margin-top:4px;font-weight:600;">
                <?php echo esc_html( $s['label'] ); ?>
              </div>
            </div>
          </td>
          <?php endforeach; ?>
        </tr>
      </table>
    </td>
  </tr>

  <!-- DIVIDER -->
  <tr>
    <td style="background:#fff;padding:0 40px;">
      <div style="border-top:1px solid #f0f0f0;"></div>
    </td>
  </tr>

  <!-- ACTIVITY LIST -->
  <tr>
    <td style="background:#fff;padding:24px 40px;">
      <div style="font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#94a3b8;margin-bottom:14px;">
        Today's Changes
      </div>
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <?php echo $activity_html; ?>
      </table>
    </td>
  </tr>

  <?php if ( ! empty( $err_lines ) ) : ?>
  <!-- ERRORS -->
  <tr>
    <td style="background:#fff;padding:0 40px 24px;">
      <div style="font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#D42B2B;margin-bottom:10px;">
        Errors
      </div>
      <div style="background:#1d2327;border-radius:6px;padding:14px 16px;">
        <?php echo $error_html; ?>
      </div>
    </td>
  </tr>
  <?php endif; ?>

  <!-- FOOTER -->
  <tr>
    <td style="background:#1a1a1a;border-radius:0 0 10px 10px;padding:18px 40px;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td>
            <span style="font-size:12px;color:#555;">
              Sent by <strong style="color:#888;">TNT Marine Sync</strong> &mdash; ideaBoss.io
            </span>
          </td>
          <td align="right">
            <span style="font-size:11px;color:#444;">v<?php echo TNTS_VERSION; ?></span>
          </td>
        </tr>
      </table>
    </td>
  </tr>

</table>
</td></tr>
</table>
</body>
</html>
    <?php
    return ob_get_clean();
}


// ============================================================
// 10e. HTML EMAIL BUILDER — legacy alias kept for Test Tab button
// ============================================================

function tnts_build_notification_email( array $result ) {
    $added    = (int) ( $result['added']    ?? 0 );
    $updated  = (int) ( $result['updated']  ?? 0 );
    $img_proc = (int) ( $result['img_proc'] ?? 0 );
    $errors   = (int) ( $result['errors']   ?? 0 );
    $log      = (array) ( $result['log']    ?? [] );

    $sync_time    = current_time( 'F j, Y \a\t g:i A' );
    $has_errors   = $errors > 0;
    $status_color = $has_errors ? '#D42B2B' : '#1a9e4f';
    $status_bg    = $has_errors ? '#fff0f0' : '#f0fff5';
    $status_label = $has_errors ? '⚠&nbsp; Completed with Errors' : '✓&nbsp; Sync Successful';
    $status_icon  = $has_errors ? '⚠️' : '✅';

    // Build log lines with color coding
    $log_rows = '';
    foreach ( $log as $line ) {
        $line = esc_html( $line );
        if ( strpos( $line, '[ERROR]' ) !== false || strpos( $line, '✗' ) !== false ) {
            $color = '#f92672';
        } elseif ( strpos( $line, '[WARN]' ) !== false ) {
            $color = '#fd971f';
        } elseif ( strpos( $line, '[Added]' ) !== false ) {
            $color = '#66d9ef';
        } elseif ( strpos( $line, '[Updated]' ) !== false ) {
            $color = '#a6e22e';
        } elseif ( strpos( $line, '[TIP]' ) !== false || strpos( $line, 'Tip:' ) !== false ) {
            $color = '#e6db74';
        } elseif ( strpos( $line, 'Sync complete' ) !== false || strpos( $line, '✓' ) !== false ) {
            $color = '#a6e22e';
        } else {
            $color = '#ccc';
        }
        $log_rows .= '<span style="color:' . $color . ';display:block;line-height:1.65;">' . $line . '</span>';
    }

    ob_start();
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TNT Marine Sync Report</title>
</head>
<body style="margin:0;padding:0;background-color:#f2f2f2;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f2f2f2;padding:32px 0;">
<tr><td align="center">
<table width="620" cellpadding="0" cellspacing="0" border="0" style="max-width:620px;width:100%;">

  <!-- ── HEADER ─────────────────────────────────── -->
  <tr>
    <td style="background:#111111;border-radius:10px 10px 0 0;padding:36px 40px 28px;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td>
            <!-- Logo lockup -->
            <div style="display:inline-block;">
              <span style="font-size:28px;font-weight:900;letter-spacing:-0.5px;color:#ffffff;line-height:1;">
                <span style="color:#D42B2B;">TNT</span> MARINE
              </span>
              <div style="margin-top:4px;font-size:11px;letter-spacing:3px;text-transform:uppercase;color:#888888;font-weight:500;">
                Listing Sync Report
              </div>
            </div>
          </td>
          <td align="right" valign="middle">
            <div style="font-size:11px;color:#666666;text-align:right;line-height:1.6;">
              <?php echo esc_html( $sync_time ); ?>
            </div>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- ── STATUS BANNER ──────────────────────────── -->
  <tr>
    <td style="background:<?php echo $status_bg; ?>;border-left:4px solid <?php echo $status_color; ?>;padding:14px 40px;">
      <span style="font-size:14px;font-weight:700;color:<?php echo $status_color; ?>;">
        <?php echo $status_label; ?>
      </span>
    </td>
  </tr>

  <!-- ── STAT CARDS ─────────────────────────────── -->
  <tr>
    <td style="background:#ffffff;padding:32px 40px 24px;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <?php
          $stats = [
              [ 'label' => 'Added',   'value' => $added,    'accent' => '#66d9ef', 'icon' => '＋' ],
              [ 'label' => 'Updated', 'value' => $updated,  'accent' => '#a6e22e', 'icon' => '↻'  ],
              [ 'label' => 'Images',  'value' => $img_proc, 'accent' => '#e6db74', 'icon' => '⬛' ],
              [ 'label' => 'Errors',  'value' => $errors,   'accent' => $errors > 0 ? '#D42B2B' : '#888888', 'icon' => '⚠' ],
          ];
          foreach ( $stats as $stat ) :
          ?>
          <td width="25%" style="padding:0 6px 0 0;">
            <div style="background:#f8f8f8;border-top:3px solid <?php echo $stat['accent']; ?>;border-radius:6px;padding:16px 14px;text-align:center;">
              <div style="font-size:28px;font-weight:900;color:#111111;line-height:1;">
                <?php echo number_format( $stat['value'] ); ?>
              </div>
              <div style="font-size:11px;text-transform:uppercase;letter-spacing:1.5px;color:#888888;margin-top:5px;font-weight:600;">
                <?php echo esc_html( $stat['label'] ); ?>
              </div>
            </div>
          </td>
          <?php endforeach; ?>
        </tr>
      </table>
    </td>
  </tr>

  <!-- ── DIVIDER ────────────────────────────────── -->
  <tr>
    <td style="background:#ffffff;padding:0 40px;">
      <div style="border-top:1px solid #eeeeee;"></div>
    </td>
  </tr>

  <!-- ── SYNC LOG ───────────────────────────────── -->
  <tr>
    <td style="background:#ffffff;padding:24px 40px 32px;">
      <div style="font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#888888;margin-bottom:12px;">
        Sync Log
      </div>
      <div style="background:#1d2327;border-radius:6px;padding:18px 20px;overflow:hidden;">
        <pre style="margin:0;font-family:'Courier New',Courier,monospace;font-size:12px;line-height:1.65;white-space:pre-wrap;word-break:break-word;"><?php echo $log_rows; ?></pre>
      </div>
    </td>
  </tr>

  <!-- ── FOOTER ─────────────────────────────────── -->
  <tr>
    <td style="background:#1a1a1a;border-radius:0 0 10px 10px;padding:20px 40px;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td>
            <span style="font-size:12px;color:#555555;">
              Sent by <strong style="color:#888888;">TNT Marine Sync</strong> &mdash; ideaBoss.io
            </span>
          </td>
          <td align="right">
            <span style="font-size:11px;color:#444444;">v<?php echo TNTS_VERSION; ?></span>
          </td>
        </tr>
      </table>
    </td>
  </tr>

</table>
</td></tr>
</table>

</body>
</html>
    <?php
    return ob_get_clean();
}


// ============================================================
// 11.  WP-CRON — Dynamic, settings-driven interval
// ============================================================

add_filter( 'cron_schedules', function ( $schedules ) {
    $interval = tnts_interval();
    $schedules['tnts_dynamic'] = [
        'interval' => $interval,
        'display'  => sprintf( 'TNT Sync — every %d min', round( $interval / 60 ) ),
    ];
    return $schedules;
} );

register_activation_hook( __FILE__, function () {
    // Sync cron
    if ( ! wp_next_scheduled( TNTS_CRON_HOOK ) && tnts_sync_enabled() ) {
        wp_schedule_event( time() + tnts_interval(), 'tnts_dynamic', TNTS_CRON_HOOK );
    }
    // Daily 10 am summary email cron
    if ( ! wp_next_scheduled( TNTS_DAILY_EMAIL_HOOK ) && tnts_notify_email() ) {
        wp_schedule_event( tnts_next_10am_utc(), 'daily', TNTS_DAILY_EMAIL_HOOK );
    }
} );

register_deactivation_hook( __FILE__, function () {
    wp_clear_scheduled_hook( TNTS_CRON_HOOK );
    wp_clear_scheduled_hook( TNTS_DAILY_EMAIL_HOOK );
} );

add_action( TNTS_CRON_HOOK, 'tnts_run_sync' );

function tnts_reschedule_cron() {
    wp_clear_scheduled_hook( TNTS_CRON_HOOK );
    if ( tnts_sync_enabled() ) {
        wp_schedule_event( time() + tnts_interval(), 'tnts_dynamic', TNTS_CRON_HOOK );
    }
}


// ============================================================
// 12.  KEYWORDS META BOX
// ============================================================

add_action( 'add_meta_boxes', function () {
    add_meta_box(
        'tnts_keywords_box',
        'SEO Keywords',
        'tnts_keywords_meta_box_cb',
        TNTS_CPT,
        'normal',
        'low'
    );
} );

function tnts_keywords_meta_box_cb( $post ) {
    wp_nonce_field( 'tnts_keywords_save', 'tnts_keywords_nonce' );
    $val = esc_textarea( get_post_meta( $post->ID, '_tnt_keywords', true ) );
    echo '<p style="margin:8px 0 4px;">'
        . '<textarea name="_tnt_keywords" rows="3" class="widefat">' . $val . '</textarea>'
        . '</p>'
        . '<p style="color:#646970;font-size:12px;margin:0;">'
        . 'Comma-separated keywords. Synced automatically from Google Sheet. Manual edits will be overwritten on next sync.'
        . '</p>';
}

add_action( 'save_post_' . TNTS_CPT, function ( $post_id ) {
    if ( ! isset( $_POST['tnts_keywords_nonce'] )
      || ! wp_verify_nonce( $_POST['tnts_keywords_nonce'], 'tnts_keywords_save' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    update_post_meta(
        $post_id,
        '_tnt_keywords',
        sanitize_textarea_field( wp_unslash( $_POST['_tnt_keywords'] ?? '' ) )
    );
} );


// ============================================================
// 13.  ADMIN MENU
// ============================================================

add_action( 'admin_menu', function () {
    add_menu_page(
        'Boat Sync',
        'Boat Sync',
        'manage_options',
        'tnt-boat-sync',
        'tnts_admin_page',
        'dashicons-update',
        30
    );
} );

function tnts_tab_nav( $active ) {
    $tabs = [ 'sync' => 'Sync', 'settings' => 'Settings' ];
    echo '<nav class="nav-tab-wrapper" style="margin-bottom:0;">';
    foreach ( $tabs as $slug => $label ) {
        $url = admin_url( 'admin.php?page=tnt-boat-sync&tab=' . $slug );
        $cls = $active === $slug ? ' nav-tab-active' : '';
        printf( '<a href="%s" class="nav-tab%s">%s</a>', esc_url( $url ), $cls, esc_html( $label ) );
    }
    echo '</nav>';
}

function tnts_admin_page() {
    $tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'sync';
    ?>
    <div class="wrap">
        <h1 style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
            <span class="dashicons dashicons-update" style="font-size:30px;width:30px;height:30px;margin-top:2px;"></span>
            Boat Sync &mdash; TNT Marine
            <span style="font-size:13px;color:#646970;font-weight:400;">v<?php echo TNTS_VERSION; ?> &mdash; ideaBoss.io</span>
        </h1>
        <?php tnts_tab_nav( $tab ); ?>
        <div style="background:#fff;border:1px solid #c3c4c7;border-top:none;padding:28px 24px;max-width:920px;">
            <?php $tab === 'settings' ? tnts_settings_page_content() : tnts_sync_page_content(); ?>
        </div>
    </div>
    <?php
}


// ============================================================
// 14.  SYNC TAB
// ============================================================

function tnts_sync_page_content() {
    $last_sync = get_option( 'tnts_last_sync', 'Never' );
    $last_log  = get_option( 'tnts_last_log',  '' );
    $next_ts   = wp_next_scheduled( TNTS_CRON_HOOK );
    $next_str  = $next_ts
        ? esc_html( get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $next_ts ) ) )
        : 'Not scheduled — save Settings to reschedule.';
    ?>

    <table style="border:none;border-collapse:collapse;width:100%;line-height:2;margin-bottom:22px;">
        <tr>
            <td style="width:180px;color:#646970;font-weight:600;">Auto-sync</td>
            <td><?php echo tnts_sync_enabled()
                ? '<span style="color:#00a32a;">&#10003; Enabled</span>'
                : '<span style="color:#d63638;">&#10007; Disabled</span>'; ?></td>
        </tr>
        <tr>
            <td style="color:#646970;font-weight:600;">Interval</td>
            <td><?php echo esc_html( tnts_interval_label( tnts_interval() ) ); ?></td>
        </tr>
        <tr>
            <td style="color:#646970;font-weight:600;">Image sync</td>
            <td><?php echo tnts_sync_images()
                ? '<span style="color:#00a32a;">&#10003; On</span>'
                : '<span style="color:#d63638;">&#10007; Off</span>'; ?>
                <?php if ( tnts_sync_images() ) echo '<span style="color:#646970;font-size:12px;"> (max ' . tnts_max_images() . ' per listing)</span>'; ?></td>
        </tr>
        <tr>
            <td style="color:#646970;font-weight:600;">Active tab</td>
            <td><code><?php echo esc_html( tnts_active_tab() ); ?></code></td>
        </tr>
        <tr>
            <td style="color:#646970;font-weight:600;">Sold tab</td>
            <td><code><?php echo esc_html( tnts_sold_tab() ); ?></code>
                <?php if ( tnts_sold_force_sold() ) echo '<span style="color:#646970;font-size:12px;"> (Force Sold: ON)</span>'; ?></td>
        </tr>
        <tr>
            <td style="color:#646970;font-weight:600;">Last sync</td>
            <td><?php echo esc_html( $last_sync ); ?></td>
        </tr>
        <tr>
            <td style="color:#646970;font-weight:600;">Next auto-sync</td>
            <td><?php echo $next_str; ?></td>
        </tr>
    </table>

    <!-- Action buttons -->
    <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:24px;">
        <button id="tnts-sync-btn" class="button button-primary" style="font-size:14px;height:36px;padding:0 18px;">
            &#9654;&nbsp; Sync Now
        </button>
        <button id="tnts-test-btn" class="button" style="height:36px;padding:0 14px;">
            &#128269;&nbsp; Test Tab Connection
        </button>
        <button id="tnts-clear-btn" class="button" style="height:36px;padding:0 14px;color:#d63638;">
            &#128465;&nbsp; Clear Token Cache
        </button>
        <span id="tnts-spinner" class="spinner" style="float:none;vertical-align:middle;display:none;margin:0;"></span>
        <span id="tnts-status-msg" style="font-size:13px;color:#646970;"></span>
    </div>

    <!-- Live log output -->
    <div id="tnts-log" style="margin-top:0;">
        <h3 style="margin:0 0 8px;font-size:12px;text-transform:uppercase;letter-spacing:.6px;color:#50575e;">
            Sync Log
            <span id="tnts-log-badge" style="display:none;margin-left:8px;background:#d63638;color:#fff;font-size:10px;padding:1px 6px;border-radius:10px;font-weight:700;letter-spacing:0;">LIVE</span>
        </h3>
        <pre id="tnts-log-output"
             style="background:#1d2327;color:#a6e22e;padding:16px 20px;border-radius:4px;
                    max-height:500px;overflow-y:auto;font-size:12.5px;line-height:1.7;
                    white-space:pre-wrap;word-break:break-word;margin:0;"><?php
            echo $last_log
                ? esc_html( $last_log )
                : '<span style="opacity:.45;">No sync has been run yet. Click "Sync Now" to start.</span>';
        ?></pre>
    </div>

    <script>
    (function () {
        var btn      = document.getElementById('tnts-sync-btn');
        var testBtn  = document.getElementById('tnts-test-btn');
        var clearBtn = document.getElementById('tnts-clear-btn');
        var spinner  = document.getElementById('tnts-spinner');
        var logOut   = document.getElementById('tnts-log-output');
        var badge    = document.getElementById('tnts-log-badge');
        var statusEl = document.getElementById('tnts-status-msg');
        var ajaxUrl  = '<?php echo admin_url( 'admin-ajax.php' ); ?>';
        var nonce    = '<?php echo wp_create_nonce( 'tnts_sync_now' ); ?>';

        function setWorking( msg ) {
            [btn, testBtn, clearBtn].forEach(function(b){ b.disabled = true; });
            spinner.style.display = 'inline-block';
            badge.style.display   = 'inline-block';
            statusEl.textContent  = msg || '';
            logOut.style.color    = '#a6e22e';
        }
        function setDone( msg ) {
            [btn, testBtn, clearBtn].forEach(function(b){ b.disabled = false; });
            spinner.style.display = 'none';
            badge.style.display   = 'none';
            statusEl.textContent  = msg || '';
        }

        function doAjax( action, onSuccess, onError ) {
            var fd = new FormData();
            fd.append('action', action);
            fd.append('nonce',  nonce);
            fetch(ajaxUrl, { method: 'POST', body: fd })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.error) { onError(data.error); }
                    else            { onSuccess(data); }
                })
                .catch(function(e) { onError('Request failed: ' + e); });
        }

        btn.addEventListener('click', function () {
            setWorking('Connecting to Google Sheets…');
            logOut.textContent = 'Connecting to Google Sheets…';
            doAjax(
                'tnts_sync_now',
                function(data) {
                    logOut.style.color = '#a6e22e';
                    logOut.textContent = data.log.join('\n');
                    setDone('Sync complete.');
                },
                function(err) {
                    logOut.style.color = '#f92672';
                    logOut.textContent = 'ERROR: ' + err;
                    setDone('Sync failed.');
                }
            );
        });

        testBtn.addEventListener('click', function () {
            setWorking('Testing tab connections…');
            logOut.textContent = 'Testing connection to Google Sheets…';
            doAjax(
                'tnts_test_tabs',
                function(data) {
                    logOut.style.color = '#a6e22e';
                    logOut.textContent = data.log.join('\n');
                    setDone('Test complete.');
                },
                function(err) {
                    logOut.style.color = '#f92672';
                    logOut.textContent = 'ERROR: ' + err;
                    setDone('Test failed.');
                }
            );
        });

        clearBtn.addEventListener('click', function () {
            if (!confirm('Delete the cached Google auth token? A fresh token will be fetched on the next sync.')) return;
            setWorking('Clearing token…');
            doAjax(
                'tnts_clear_token',
                function(data) {
                    logOut.style.color = '#a6e22e';
                    logOut.textContent = data.message;
                    setDone('Token cleared.');
                },
                function(err) {
                    logOut.style.color = '#f92672';
                    logOut.textContent = 'ERROR: ' + err;
                    setDone('');
                }
            );
        });
    }());
    </script>
    <?php
}


// ============================================================
// 15.  SETTINGS TAB
// ============================================================

function tnts_interval_options() {
    return [
        900   => 'Every 15 minutes',
        1800  => 'Every 30 minutes',
        3600  => 'Every 1 hour',
        7200  => 'Every 2 hours',
        14400 => 'Every 4 hours',
        21600 => 'Every 6 hours',
        43200 => 'Every 12 hours',
        86400 => 'Every 24 hours',
    ];
}

function tnts_interval_label( $seconds ) {
    $opts = tnts_interval_options();
    return $opts[ (int) $seconds ] ?? round( $seconds / 60 ) . ' minutes';
}

/** Settings form POST handler */
add_action( 'admin_init', function () {
    if ( ! isset( $_POST['tnts_settings_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['tnts_settings_nonce'], 'tnts_save_settings' ) ) wp_die( 'Security check failed.' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorised.' );

    $old_interval = tnts_interval();
    $old_enabled  = tnts_sync_enabled();

    $new_interval = (int) ( $_POST['tnts_interval'] ?? TNTS_DEFAULT_INTERVAL );
    $new_enabled  = isset( $_POST['tnts_sync_enabled'] ) ? '1' : '0';

    // Sync schedule
    update_option( 'tnts_interval',     $new_interval );
    update_option( 'tnts_sync_enabled', $new_enabled );

    // Data source
    update_option( 'tnts_sheet_id',   sanitize_text_field( $_POST['tnts_sheet_id']   ?? TNTS_DEFAULT_SHEET_ID ) );
    update_option( 'tnts_active_tab', sanitize_text_field( trim( $_POST['tnts_active_tab'] ?? TNTS_DEFAULT_ACTIVE_TAB ) ) );
    update_option( 'tnts_sold_tab',   sanitize_text_field( trim( $_POST['tnts_sold_tab']   ?? TNTS_DEFAULT_SOLD_TAB ) ) );

    // Listing behavior
    update_option( 'tnts_default_status',  sanitize_text_field( $_POST['tnts_default_status']  ?? 'publish' ) );
    update_option( 'tnts_sold_force_sold', isset( $_POST['tnts_sold_force_sold'] ) ? '1' : '0' );

    // Images
    update_option( 'tnts_sync_images', isset( $_POST['tnts_sync_images'] ) ? '1' : '0' );
    update_option( 'tnts_max_images',  max( 1, (int) ( $_POST['tnts_max_images'] ?? 20 ) ) );

    // Notifications & logging
    update_option( 'tnts_notify_email',  sanitize_email( $_POST['tnts_notify_email']  ?? '' ) );
    update_option( 'tnts_log_verbosity', sanitize_text_field( $_POST['tnts_log_verbosity'] ?? 'normal' ) );

    // Reschedule sync cron if schedule-related settings changed
    if ( $old_interval !== $new_interval || $old_enabled !== ( $new_enabled === '1' ) ) {
        tnts_reschedule_cron();
    }

    // Reschedule daily email cron if notification email was added or removed
    $new_notify = sanitize_email( $_POST['tnts_notify_email'] ?? '' );
    wp_clear_scheduled_hook( TNTS_DAILY_EMAIL_HOOK );
    if ( $new_notify && ! wp_next_scheduled( TNTS_DAILY_EMAIL_HOOK ) ) {
        wp_schedule_event( tnts_next_10am_utc(), 'daily', TNTS_DAILY_EMAIL_HOOK );
    }

    wp_redirect( admin_url( 'admin.php?page=tnt-boat-sync&tab=settings&saved=1' ) );
    exit;
} );

function tnts_settings_page_content() {
    if ( isset( $_GET['saved'] ) ) {
        echo '<div class="notice notice-success inline" style="margin:0 0 20px;"><p><strong>Settings saved.</strong></p></div>';
    }
    $section_style = 'padding-bottom:10px;border-bottom:1px solid #f0f0f0;font-size:14px;color:#1d2327;';
    ?>
    <form method="post" action="">
        <?php wp_nonce_field( 'tnts_save_settings', 'tnts_settings_nonce' ); ?>

        <!-- ── SYNC SCHEDULE ── -->
        <h2 style="margin-top:0;<?php echo $section_style; ?>">Sync Schedule</h2>
        <table class="form-table" style="margin-top:0;">
            <tr>
                <th scope="row" style="width:220px;">Auto-sync</th>
                <td>
                    <label>
                        <input type="checkbox" name="tnts_sync_enabled" value="1" <?php checked( tnts_sync_enabled() ); ?>>
                        Enable automatic background syncing
                    </label>
                    <p class="description">Uncheck to pause auto-sync. Manual sync via the Sync tab still works at any time.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Sync every</th>
                <td>
                    <select name="tnts_interval" style="min-width:210px;">
                        <?php foreach ( tnts_interval_options() as $secs => $label ) : ?>
                            <option value="<?php echo $secs; ?>" <?php selected( tnts_interval(), $secs ); ?>>
                                <?php echo esc_html( $label ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description">Changing this reschedules the cron job immediately.</p>
                </td>
            </tr>
        </table>

        <!-- ── DATA SOURCE ── -->
        <h2 style="<?php echo $section_style; ?>margin-top:32px;">Data Source</h2>
        <table class="form-table" style="margin-top:0;">
            <tr>
                <th scope="row">Google Sheet ID</th>
                <td>
                    <input type="text" name="tnts_sheet_id" value="<?php echo esc_attr( tnts_sheet_id() ); ?>" class="regular-text" style="font-family:monospace;">
                    <p class="description">Found in your Sheet URL: <code>docs.google.com/spreadsheets/d/<strong>[SHEET_ID]</strong>/edit</code></p>
                </td>
            </tr>
            <tr>
                <th scope="row">Active listings tab name</th>
                <td>
                    <input type="text" name="tnts_active_tab" value="<?php echo esc_attr( tnts_active_tab() ); ?>" class="regular-text">
                    <p class="description">Must match the tab name <strong>exactly</strong> — case-sensitive, no leading/trailing spaces. Default: <code>Active Listings</code></p>
                </td>
            </tr>
            <tr>
                <th scope="row">Sold listings tab name</th>
                <td>
                    <input type="text" name="tnts_sold_tab" value="<?php echo esc_attr( tnts_sold_tab() ); ?>" class="regular-text">
                    <p class="description">Must match the tab name exactly. Default: <code>Sold</code></p>
                </td>
            </tr>
        </table>

        <!-- ── LISTING BEHAVIOR ── -->
        <h2 style="<?php echo $section_style; ?>margin-top:32px;">Listing Behavior</h2>
        <table class="form-table" style="margin-top:0;">
            <tr>
                <th scope="row">Default publish status</th>
                <td>
                    <select name="tnts_default_status" style="min-width:160px;">
                        <option value="publish" <?php selected( tnts_default_status(), 'publish' ); ?>>Published</option>
                        <option value="draft"   <?php selected( tnts_default_status(), 'draft' ); ?>>Draft</option>
                    </select>
                    <p class="description">Applied to rows where the <em>Status</em> column is empty. Rows with "Publish", "Draft", or "Sold" in that column always override this.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Sold tab: Force Sold flag</th>
                <td>
                    <label>
                        <input type="checkbox" name="tnts_sold_force_sold" value="1" <?php checked( tnts_sold_force_sold() ); ?>>
                        Mark every row on the Sold tab as sold, regardless of its Status column value
                    </label>
                    <p class="description">Recommended: ON. Ensures listings moved to the Sold tab are always hidden from the live site.</p>
                </td>
            </tr>
        </table>

        <!-- ── IMAGES ── -->
        <h2 style="<?php echo $section_style; ?>margin-top:32px;">Image Sync</h2>
        <table class="form-table" style="margin-top:0;">
            <tr>
                <th scope="row">Download images</th>
                <td>
                    <label>
                        <input type="checkbox" name="tnts_sync_images" value="1" <?php checked( tnts_sync_images() ); ?>>
                        Download photos from Google Drive and add to Media Library
                    </label>
                    <p class="description">Uncheck to skip all image downloads (useful for fast test syncs or if photos are managed manually).</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Max images per listing</th>
                <td>
                    <input type="number" name="tnts_max_images" value="<?php echo esc_attr( tnts_max_images() ); ?>" min="1" max="100" style="width:80px;">
                    <p class="description">Caps how many photos are downloaded per boat. Prevents server timeouts on listings with large galleries. Default: 20.</p>
                </td>
            </tr>
        </table>

        <!-- ── NOTIFICATIONS & LOGGING ── -->
        <h2 style="<?php echo $section_style; ?>margin-top:32px;">Notifications &amp; Logging</h2>
        <table class="form-table" style="margin-top:0;">
            <tr>
                <th scope="row">Email after sync</th>
                <td>
                    <input type="email" name="tnts_notify_email" value="<?php echo esc_attr( tnts_notify_email() ); ?>" class="regular-text" placeholder="Leave blank to disable">
                    <p class="description">Receives a <strong>daily summary email at 10 AM</strong> covering all syncs run that day — new listings, updates, unchanged count, and any errors. Manual syncs and individual hourly runs do not send email. Saving a new address here schedules the cron automatically.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Log verbosity</th>
                <td>
                    <select name="tnts_log_verbosity" style="min-width:160px;">
                        <option value="normal"  <?php selected( tnts_log_verbosity(), 'normal' ); ?>>Normal</option>
                        <option value="verbose" <?php selected( tnts_log_verbosity(), 'verbose' ); ?>>Verbose (debug)</option>
                    </select>
                    <p class="description">Verbose mode logs detected column names and skipped images — useful for troubleshooting.</p>
                </td>
            </tr>
        </table>

        <p style="margin-top:28px;padding-top:16px;border-top:1px solid #f0f0f0;">
            <?php submit_button( 'Save Settings', 'primary', 'submit', false ); ?>
        </p>
    </form>
    <?php
}


// ============================================================
// 16.  AJAX HANDLERS
// ============================================================

// ── Sync Now
add_action( 'wp_ajax_tnts_sync_now', function () {
    check_ajax_referer( 'tnts_sync_now', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( [ 'error' => 'Insufficient permissions.' ], 403 );
    @set_time_limit( 300 );
    wp_send_json( tnts_run_sync() );
} );

// ── Test Tab Connection (read-only — no DB writes)
add_action( 'wp_ajax_tnts_test_tabs', function () {
    check_ajax_referer( 'tnts_sync_now', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( [ 'error' => 'Insufficient permissions.' ], 403 );

    $log   = [];
    $token = tnts_get_access_token();

    if ( is_wp_error( $token ) ) {
        wp_send_json( [ 'log' => [ '[ERROR] Authentication failed: ' . $token->get_error_message() ] ] );
        return;
    }

    $log[] = '✓ Google authentication OK — token obtained.';
    $log[] = '─────────────────────────────────────────────';

    // Test Active Listings tab
    $active_tab  = tnts_active_tab();
    $log[] = "Testing Active Listings tab: \"{$active_tab}\" (length: " . strlen( $active_tab ) . ")";
    $active_rows = tnts_fetch_sheet_rows( $token, $active_tab );
    if ( is_wp_error( $active_rows ) ) {
        $log[] = "  ✗ FAILED — " . $active_rows->get_error_message();
        $log[] = "  → Fix: go to Settings and update the Active Listings tab name.";
    } else {
        $total = count( $active_rows );
        $data  = max( 0, $total - 1 );
        $log[] = "  ✓ OK — {$total} row(s) returned, {$data} data row(s)";
        if ( $total > 0 ) {
            $header_preview = implode( ' | ', array_slice( $active_rows[0], 0, 6 ) );
            $log[] = "  → First 6 headers: {$header_preview}";
        }
    }

    $log[] = '─────────────────────────────────────────────';

    // Test Sold tab
    $sold_tab  = tnts_sold_tab();
    $log[] = "Testing Sold tab: \"{$sold_tab}\" (length: " . strlen( $sold_tab ) . ")";
    $sold_rows = tnts_fetch_sheet_rows( $token, $sold_tab );
    if ( is_wp_error( $sold_rows ) ) {
        $log[] = "  ✗ FAILED — " . $sold_rows->get_error_message();
        $log[] = "  → Fix: go to Settings and update the Sold tab name.";
    } else {
        $total = count( $sold_rows );
        $data  = max( 0, $total - 1 );
        $log[] = "  ✓ OK — {$total} row(s) returned, {$data} data row(s)";
        if ( $total > 0 ) {
            $header_preview = implode( ' | ', array_slice( $sold_rows[0], 0, 6 ) );
            $log[] = "  → First 6 headers: {$header_preview}";
        }
    }

    $log[] = '─────────────────────────────────────────────';
    $log[] = 'Sheet ID: ' . tnts_sheet_id();
    $log[] = 'Tip: if a tab shows FAILED, copy-paste the exact tab name from your Google Sheet into Settings.';

    wp_send_json( [ 'log' => $log ] );
} );

// ── Clear Token Cache
add_action( 'wp_ajax_tnts_clear_token', function () {
    check_ajax_referer( 'tnts_sync_now', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( [ 'error' => 'Insufficient permissions.' ], 403 );
    delete_transient( 'tnts_google_token' );
    wp_send_json( [ 'message' => '✓ Cached token deleted. A fresh token will be fetched on the next sync.' ] );
} );
